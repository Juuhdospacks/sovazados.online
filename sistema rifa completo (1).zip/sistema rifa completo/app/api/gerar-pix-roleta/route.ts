import { type NextRequest, NextResponse } from "next/server"

// Função para gerar dados falsos mantendo a integração com 4Devs
async function gerarDadosFalsos() {
  try {
    const response = await fetch("https://www.4devs.com.br/ferramentas_online.php", {
      method: "POST",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
      },
      body: new URLSearchParams({
        acao: "gerar_pessoa",
        sexo: "I",
        pontuacao: "S",
        idade: "0",
        cep_estado: "",
        cep_cidade: "",
        txt_qtde: "1",
      }),
    })

    const data = await response.json()
    return data[0] || null
  } catch (error) {
    console.error("Erro ao gerar dados falsos:", error)
    return null
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const {
      nome,
      telefone,
      amount,
      prize_name,
      utm_source,
      utm_medium,
      utm_campaign,
      utm_term,
      utm_content,
      click_id,
      CampaignID,
      CreativeID,
    } = body

    console.log("🎰 API Roleta - Dados recebidos:")
    console.log("Nome:", nome)
    console.log("Telefone:", telefone)
    console.log("Prêmio:", prize_name)
    console.log("Valor:", amount)

    // Verifica valor mínimo
    if (amount < 500) {
      return NextResponse.json({
        erro: true,
        mensagem: "O valor mínimo permitido é R$ 5,00",
      })
    }

    // Montar query string com UTMs
    const utmParams = new URLSearchParams();
    if (utm_source) utmParams.append('utm_source', utm_source);
    if (utm_medium) utmParams.append('utm_medium', utm_medium);
    if (utm_campaign) utmParams.append('utm_campaign', utm_campaign);
    if (utm_term) utmParams.append('utm_term', utm_term);
    if (utm_content) utmParams.append('utm_content', utm_content);
    if (click_id) utmParams.append('click_id', click_id);
    if (CampaignID) utmParams.append('CampaignID', CampaignID);
    if (CreativeID) utmParams.append('CreativeID', CreativeID);

    // Criar payload básico - deixar 4Devs ser processado no PHP
    const payload = {
      nome: nome, // Se vier vazio, o PHP usará 4Devs
      telefone: telefone,
      amount: amount,
      prize_name: prize_name,
      utm_source,
      utm_medium,
      utm_campaign,
      utm_term,
      utm_content,
      click_id,
      CampaignID,
      CreativeID
    }

    // Remover campos vazios/undefined
    Object.keys(payload).forEach(key => {
      if ((payload as any)[key] === undefined || (payload as any)[key] === null || (payload as any)[key] === '') {
        delete (payload as any)[key];
      }
    });

    console.log("🎰 Payload da Roleta sendo enviado para gerar.php:")
    console.log("- Nome:", payload.nome)
    console.log("- Telefone:", payload.telefone)
    console.log("- Prêmio:", prize_name)
    console.log("- Valor:", amount)
    console.log("- CPF será gerado automaticamente pelo 4Devs")

    // Fazer requisição para o seu gerar.php
    const baseUrl = 'http://localhost:8000' // Servidor PHP
    const gerarUrl = `${baseUrl}/gerar.php?value=${(amount / 100).toFixed(2)}&${utmParams.toString()}`
    
    console.log("🔗 URL do gerar.php:", gerarUrl)

    const response = await fetch(gerarUrl, {
      method: "POST",
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(payload),
    })

    const result = await response.json()
    console.log("🎰 Resposta do gerar.php para Roleta:", result)

    // Adaptar resposta para o formato esperado pelo frontend
    if (!result.error && result.QRCode) {
      return NextResponse.json({
        error: false,
        pix_code: result.QRCode,
        pix_qr_code: result.QRCode,
        qr_code: result.QRCode,
        transaction_id: result.identifier,
        hash: result.identifier, // Adicionar hash para compatibilidade
        amount: result.valor || amount,
        pix: {
          pix_qr_code: result.QRCode,
          pix_code: result.QRCode,
          transaction_id: result.identifier
        },
        customer: {
          name: payload.nome,
          email: "gerado_automaticamente@4devs.com",
          cpf: "gerado_automaticamente",
          phone: payload.telefone
        }
      })
    } else {
      console.error("❌ Erro retornado pelo gerar.php:", result)
      return NextResponse.json({
        erro: true,
        mensagem: result.message || "Erro ao gerar PIX",
        details: result
      })
    }
  } catch (error) {
    console.error("🎰 Erro na API da Roleta:", error)
    return NextResponse.json({
      erro: true,
      mensagem: "Erro interno do servidor: " + (error instanceof Error ? error.message : String(error)),
    })
  }
}
