import { type NextRequest, NextResponse } from "next/server"

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const hash = searchParams.get("hash")

    if (!hash) {
      console.error("❌ ID da transação não fornecido na requisição")
      return NextResponse.json({
        erro: true,
        mensagem: "ID da transação não fornecido",
      })
    }

    console.log("🔍 Verificando status da transação:", hash)

    // Tentar múltiplas URLs de verificação
    const baseUrls = [
      'http://localhost:8000', // Servidor PHP local
      'http://127.0.0.1:8000', // Alternativa localhost
    ]

    let result = null
    let lastError = null

    for (const baseUrl of baseUrls) {
      try {
        const verificarUrl = `${baseUrl}/verificar.php?id=${encodeURIComponent(hash)}`
        console.log("🔗 Tentando URL:", verificarUrl)

        const response = await fetch(verificarUrl, {
          method: "GET",
          headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
          }
        })

        if (response.ok) {
          result = await response.json()
          console.log("✅ Resposta obtida com sucesso de:", baseUrl)
          break
        } else {
          console.warn(`⚠️ Falha na URL ${baseUrl}: ${response.status}`)
          lastError = new Error(`HTTP ${response.status}`)
        }
      } catch (error) {
        console.warn(`⚠️ Erro ao conectar com ${baseUrl}:`, error)
        lastError = error
        continue
      }
    }

    if (!result) {
      console.error("❌ Todas as tentativas de conexão falharam")
      return NextResponse.json({
        erro: true,
        mensagem: "Erro ao conectar com o servidor de verificação",
        debug: lastError instanceof Error ? lastError.message : "Conexão falhou"
      })
    }

    console.log("📊 Resposta do verificar.php:", JSON.stringify(result, null, 2))

    // Adaptar resposta para o formato esperado pelo frontend
    if (result.success) {
      const status = result.status ? result.status.toUpperCase() : 'PENDING'
      
      // Mapear status para o formato esperado pelo frontend
      const paymentStatus = (status === 'APPROVED' || status === 'PAID') ? 'paid' : 'pending'
      
      console.log("📌 Status processado:", status, "→", paymentStatus)
      
      return NextResponse.json({
        success: true,
        status: status,
        payment_status: paymentStatus, // Campo principal que o frontend procura
        transaction_id: result.transaction_id || hash,
        amount: result.amount,
        payment_method: result.method || 'PIX',
        created_at: result.created_at,
        updated_at: result.updated_at,
        customer: result.customer,
        pix_code: result.pixCode,
        pix_qr_code: result.pixQrCode,
        expires_at: result.expires_at,
        paid_at: result.paid_at,
        // Campos adicionais para compatibilidade
        erro: (status === 'APPROVED' || status === 'PAID') ? false : undefined,
        approved: (status === 'APPROVED' || status === 'PAID')
      })
    } else {
      console.error("❌ Resposta indicou falha:", result)
      return NextResponse.json({
        erro: true,
        mensagem: (result as any)?.message || "Erro ao verificar status da transação",
        success: false,
        status: 'ERROR',
        debug: result
      })
    }
  } catch (error) {
    console.error("❌ Erro geral na verificação:", error)
    return NextResponse.json({
      erro: true,
      mensagem: "Erro interno ao verificar status da transação",
      success: false,
      status: 'ERROR',
      debug: error instanceof Error ? error.message : String(error)
    })
  }
}
